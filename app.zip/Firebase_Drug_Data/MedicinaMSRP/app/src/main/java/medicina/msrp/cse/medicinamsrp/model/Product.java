package medicina.msrp.cse.medicinamsrp.model;

/**
 * Created by Priyanka on 12-04-2018.
 */

public class Product {
    private String medName,medType;

    public Product(String medName, String medType) {
        this.medName = medName;
        this.medType = medType;
    }

    public String getMedName() {
        return medName;
    }

    public String getMedType() {
        return medType;
    }
}
