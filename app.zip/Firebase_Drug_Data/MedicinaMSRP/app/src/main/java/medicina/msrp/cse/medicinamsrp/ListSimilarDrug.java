package medicina.msrp.cse.medicinamsrp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import medicina.msrp.cse.medicinamsrp.model.Product;

import java.util.List;

/**
 * Created by Priyanka on 12-04-2018.
 */

public class ListSimilarDrug extends BaseAdapter{
    private Context mContext;
    private List<Product> similardruglist;

    public ListSimilarDrug(Context mContext, List<Product> similardruglist) {
        this.mContext = mContext;
        this.similardruglist = similardruglist;
    }

    @Override
    public int getCount() {
        return similardruglist.size();
    }

    @Override
    public Object getItem(int position) {
        return similardruglist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=View.inflate(mContext, R.layout.similar_drug_name,null);
        TextView t1=(TextView)v.findViewById(R.id.txtName);
        TextView t2=(TextView)v.findViewById(R.id.texttypeofdrug);
        t1.setText(similardruglist.get(position).getMedType()+" :- ");
        t2.setText(similardruglist.get(position).getMedName());
        return v;
    }
}
