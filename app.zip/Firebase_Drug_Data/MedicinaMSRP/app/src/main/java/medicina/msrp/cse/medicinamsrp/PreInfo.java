package medicina.msrp.cse.medicinamsrp;

/**
 * Created by Malik on 4/12/2018.
 */

public class PreInfo {

    public String medicinenm;
    public String dosage;
    public String medvalue;

    public PreInfo(String medicinenm, String dosage, String medvalue) {
        this.medicinenm = medicinenm;
        this.dosage = dosage;
        this.medvalue = medvalue;
    }
}
