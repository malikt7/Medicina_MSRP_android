package medicina.msrp.cse.medicinamsrp.model;

/**
 * Created by Priyanka on 12-04-2018.
 */

public class contentinfo {
    private int cId;
    private String cNmae,CcontentInfo;

    public contentinfo(int cId, String cNmae, String ccontentInfo) {
        this.cId = cId;
        this.cNmae = cNmae;
        CcontentInfo = ccontentInfo;
    }

    public int getcId() {
        return cId;
    }

    public String getcNmae() {
        return cNmae;
    }

    public String getCcontentInfo() {
        return CcontentInfo;
    }
}
