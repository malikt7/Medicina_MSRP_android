package medicina.msrp.cse.medicinamsrp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PreFetchActivity extends AppCompatActivity {

    private DatabaseReference mUserDatabase;
    private FirebaseUser mCurrentUser;
    Context context;
    private FirebaseDatabase firebaseDatabase;

    private TextView textmed, textdos, textmedval;

    private ListView listView;

    List<String> itemlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_fetch);

        textmed = (TextView) findViewById(R.id.textmed);
        textdos = (TextView) findViewById(R.id.textdos);
        textmedval = (TextView) findViewById(R.id.textmedval);

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String current_uid = mCurrentUser.getUid();

        itemlist = new ArrayList<>();
        firebaseDatabase = FirebaseDatabase.getInstance();
        mUserDatabase = firebaseDatabase.getReference().child(current_uid).child("Prescription");

        mUserDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String mMed = dataSnapshot.child("medicinenm").getValue().toString();
                String mdos = dataSnapshot.child("dosage").getValue().toString();
                String mvalue = dataSnapshot.child("medvalue").getValue().toString();


                textmed.setText(mMed);
                textdos.setText(mdos);
                textmedval.setText(mvalue);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
