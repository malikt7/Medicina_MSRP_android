package medicina.msrp.cse.medicinamsrp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import medicina.msrp.cse.medicinamsrp.model.PriscriptionTemplet;

import java.util.List;

/**
 * Created by Priyanka on 09-04-2018.
 */

public class ShowPriscription extends BaseAdapter {
    private Context mContext;
    private List<PriscriptionTemplet> mlistPris;

    public ShowPriscription(Context mContext, List<PriscriptionTemplet> mlistPris) {
        this.mContext = mContext;
        this.mlistPris = mlistPris;
    }

    @Override
    public int getCount() {
        return mlistPris.size();
    }

    @Override
    public Object getItem(int position) {
        return mlistPris.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mlistPris.get(position).getMedId();
    }
    public int getid(int position){
        return mlistPris.get(position).getMedId();
    }
    public String getname(int position){
        return mlistPris.get(position).getMedName();
    }
    public  String getcontent(int position){
        return mlistPris.get(position).getMedContent();
    }
    public String getdosage(int position){return mlistPris.get(position).getDosage();}
    public String getquantity(int position){
        return mlistPris.get(position).getMedQuantity();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=View.inflate(mContext, R.layout.viewpriscription,null);
        TextView t1,t2,t3;


        t1=(TextView)v.findViewById(R.id.text_med_name);
        t2=(TextView)v.findViewById(R.id.text_med_dosage);
        t3=(TextView)v.findViewById(R.id.text_med_quantity);


        t1.setText(getname(position));
        t2.setText(mlistPris.get(position).getDosage());
        t3.setText("Quantity :"+mlistPris.get(position).getMedQuantity());
        return v;
    }
}
