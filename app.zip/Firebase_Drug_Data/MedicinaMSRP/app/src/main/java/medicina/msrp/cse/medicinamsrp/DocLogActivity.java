package medicina.msrp.cse.medicinamsrp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class DocLogActivity extends AppCompatActivity implements View.OnClickListener {

    docinfo doctor=new docinfo();
    String user=doctor.getUsername();
    String pass=doctor.getPassword();

    TextView DoctextView;
    EditText EditMail, EditPass;
    Button BtnDLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_log);

        DoctextView = (TextView) findViewById(R.id.DoctextView);
        EditMail = (EditText) findViewById(R.id.EditMail);
        EditPass = (EditText) findViewById(R.id.EditPass);
        BtnDLog = (Button) findViewById(R.id.BtnDLog);

        BtnDLog.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        String username =EditMail.getText().toString().trim();
        String password= EditPass.getText().toString().trim();
        if(username.equals(user) && password.equals(pass))
        {
            startActivity(new Intent(this,DocPanelActivity.class));
            Toast.makeText(this, "login done "+username, Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(this, "login not done:", Toast.LENGTH_LONG).show();
        }
    }
}
