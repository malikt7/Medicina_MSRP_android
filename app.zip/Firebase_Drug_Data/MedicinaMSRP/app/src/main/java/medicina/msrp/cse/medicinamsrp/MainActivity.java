package medicina.msrp.cse.medicinamsrp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button BtnDocLog, BtnPatLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BtnDocLog = (Button) findViewById(R.id.BtnDocLog);
        BtnPatLog = (Button) findViewById(R.id.BtnPatLog);


        BtnDocLog.setOnClickListener(this);
        BtnPatLog.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == BtnDocLog) {
            startActivity(new Intent(this,DocLogActivity.class )); // Doctor Activity
        }

        if (v == BtnPatLog){
            startActivity(new Intent(this,PatientLoginActivity.class ));

        }
    }
}
