package medicina.msrp.cse.medicinamsrp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import medicina.msrp.cse.medicinamsrp.model.contentinfo;

import java.util.List;

/**
 * Created by Priyanka on 12-04-2018.
 */

public class ListMedContentInfo extends BaseAdapter {
    private Context mContext;
    private List<contentinfo> mContentInfoList;

    public ListMedContentInfo(Context mContext, List<contentinfo> mContentInfoList) {
        this.mContext = mContext;
        this.mContentInfoList = mContentInfoList;
    }

    @Override
    public int getCount() {

        return mContentInfoList.size();
    }

    @Override
    public Object getItem(int position) {
        return mContentInfoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mContentInfoList.get(position).getcId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=View.inflate(mContext, R.layout.content_view,null);
        TextView medName=(TextView) v.findViewById(R.id.text_content);
        TextView medContent=(TextView) v.findViewById(R.id.text_contentInfo);
        medName.setText(mContentInfoList.get(position).getcNmae());
        medContent.setText(mContentInfoList.get(position).getCcontentInfo());
        return  v;
    }
}
