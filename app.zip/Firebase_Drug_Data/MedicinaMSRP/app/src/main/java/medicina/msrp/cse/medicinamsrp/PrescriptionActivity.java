package medicina.msrp.cse.medicinamsrp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PrescriptionActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth firebaseAuth;
    private Button logout2;
    private EditText Etmed,etval;
    private Button btnAdd;
    private CheckBox morning, afternoon, evening;

    public String d="Take at :";

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription);

        firebaseAuth = FirebaseAuth.getInstance();

        databaseReference = FirebaseDatabase.getInstance().getReference();

        logout2 = (Button) findViewById(R.id.logout2);
        btnAdd= (Button) findViewById(R.id.btnAdd) ;
        Etmed = (EditText) findViewById(R.id.EtMed);
        etval = (EditText) findViewById(R.id.etval);
        morning = (CheckBox) findViewById(R.id.morning);
        afternoon = (CheckBox) findViewById(R.id.afternoon);
        evening = (CheckBox) findViewById(R.id.evening);


        logout2.setOnClickListener(this);
        btnAdd.setOnClickListener(this);
    }

    public void savePre(){
        String medicinenm = Etmed.getText().toString().trim();
        if(morning.isChecked()){
            d+="Morning,";
        }
        if(afternoon.isChecked()){
            d+="Afternoon,";
        }
        if(evening.isChecked()){
            d+="Evening";
        }
        String dosage = d;

        String medvalue = etval.getText().toString().trim();

         PreInfo predata = new PreInfo(medicinenm, dosage, medvalue);

        FirebaseUser user = firebaseAuth.getCurrentUser();

        databaseReference.child(user.getUid()).child("Prescription").setValue(predata);

        Toast.makeText(this, "Prescription Saved...", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onClick(View view) {
        if(view == logout2){
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(this,DocPanelActivity.class ));
        }

        if (view == btnAdd){
            savePre();
        }
    }
}
