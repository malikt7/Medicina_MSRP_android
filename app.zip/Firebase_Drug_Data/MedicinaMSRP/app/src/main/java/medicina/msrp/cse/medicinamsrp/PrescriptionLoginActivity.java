package medicina.msrp.cse.medicinamsrp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class PrescriptionLoginActivity extends AppCompatActivity implements View.OnClickListener {

    private Button button2;
    private EditText email2;
    private EditText pass2;

    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_login);

        firebaseAuth = FirebaseAuth.getInstance();

        email2 = (EditText) findViewById(R.id.email2);
        pass2 = (EditText) findViewById(R.id.pass2);
        button2 = (Button) findViewById(R.id.button2);

        progressDialog = new ProgressDialog(this);

        button2.setOnClickListener(this);
    }

    private void userLogin(){
        String useremail = email2.getText().toString().trim();
        String userpass = pass2.getText().toString().trim();
        //Checking if email and passwords are empty
        if(TextUtils.isEmpty(useremail)){
            Toast.makeText(this, "Please Enter Email", Toast.LENGTH_LONG).show();
        }

        if(TextUtils.isEmpty(userpass)){
            Toast.makeText(this, "Please Enter Password", Toast.LENGTH_LONG).show();
        }

        //if the email and password are not empty
        //displaying a process dialog

        progressDialog.setMessage("Logging In Please Wait...");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(useremail,userpass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();
                        if(task.isSuccessful()){
                            // Start Patient Profile activity
                            finish();
                            Toast.makeText(PrescriptionLoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),ShowData.class ));
                        }
                    }
                });
    }



    @Override
    public void onClick(View view) {
        if (view == button2) {
            userLogin();
        }
    }
}
