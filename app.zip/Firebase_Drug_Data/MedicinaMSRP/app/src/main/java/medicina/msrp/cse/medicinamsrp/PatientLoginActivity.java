package medicina.msrp.cse.medicinamsrp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class PatientLoginActivity extends AppCompatActivity implements View.OnClickListener {

    private Button userLogBtn;
    private EditText userEmail;
    private EditText userLogPass;
    private TextView txtUserLog;

    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);

        firebaseAuth = FirebaseAuth.getInstance();

        if (firebaseAuth.getCurrentUser() != null){
            finish();
            startActivity(new Intent(getApplicationContext(), PatientProfileActivity.class ));
        }

        userEmail = (EditText) findViewById(R.id.userEmail);
        userLogPass = (EditText) findViewById(R.id.userLogPass);
        userLogBtn = (Button) findViewById(R.id.userLogBtn);
        txtUserLog = (TextView) findViewById(R.id.txtUserLog);

        progressDialog = new ProgressDialog(this);


        userLogBtn.setOnClickListener(this);

    }
    private void userLogin(){
      String useremail = userEmail.getText().toString().trim();
      String userpass = userLogPass.getText().toString().trim();
      //Checking if email and passwords are empty
      if(TextUtils.isEmpty(useremail)){
          Toast.makeText(this, "Please Enter Email", Toast.LENGTH_LONG).show();
      }

      if(TextUtils.isEmpty(userpass)){
          Toast.makeText(this, "Please Enter Password", Toast.LENGTH_LONG).show();
      }

      //if the email and password are not empty
        //displaying a process dialog

        progressDialog.setMessage("Logging In Please Wait...");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(useremail,userpass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();
                        if(task.isSuccessful()){
                             // Start Patient Profile activity
                            finish();
                            Toast.makeText(PatientLoginActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), PatientProfileActivity.class ));
                        }
                    }
                });
    }

    @Override
    public void onClick(View view) {
        if(view == userLogBtn){
            userLogin();

        }
    }
}
