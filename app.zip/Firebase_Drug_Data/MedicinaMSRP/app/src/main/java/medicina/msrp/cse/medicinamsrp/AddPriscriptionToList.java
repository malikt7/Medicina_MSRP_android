package medicina.msrp.cse.medicinamsrp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import medicina.msrp.cse.medicinamsrp.database.DatabaseHelper;
import medicina.msrp.cse.medicinamsrp.model.PriscriptionTemplet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class AddPriscriptionToList extends AppCompatActivity {
    private DatabaseHelper mDBHelper;
    ArrayList<String> show;
    private AutoCompleteTextView actv;
    ArrayAdapter<String> adapter;
    Button btnAdd;
    CheckBox cbMorning,cbAfternoon,cbEvening;
    PriscriptionTemplet temp=new PriscriptionTemplet();
    EditText mQuantity;
    String d="Take at :";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_priscription_to_list);
        btnAdd=(Button)findViewById(R.id.btnAddToList);
        cbMorning=(CheckBox)findViewById(R.id.CBdosageM);
        cbAfternoon=(CheckBox)findViewById(R.id.CBdosageA);
        cbEvening=(CheckBox)findViewById(R.id.CBdosageE);
        mQuantity=(EditText)findViewById(R.id.ETQuantity);
        mDBHelper=new DatabaseHelper(this);
        File database=getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        if(false==database.exists()){
            mDBHelper.getReadableDatabase();
            if(CopyDatabase(this)){
                Toast.makeText(this,"copy database successfull",Toast.LENGTH_SHORT);
            }
            else{
                Toast.makeText(this,"copy database unsuccessfull",Toast.LENGTH_SHORT);
                return;
            }
        }
        else{
            Toast.makeText(this," database unsuccessfull",Toast.LENGTH_SHORT);
        }
        show=mDBHelper.getListMedName();
        actv=(AutoCompleteTextView)findViewById(R.id.ACTV_medName1);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,show);
        actv.setAdapter(adapter);



        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(cbMorning.isChecked()){
                  d+="Morning,";
                }
                if(cbAfternoon.isChecked()){
                    d+=" Afternoon,";
                }
                if(cbEvening.isChecked()){
                    d+=" Evening";
                }
                temp.setMedName(actv.getText().toString());
                //temp.setMedId(1);
                //temp.setMedContent("axs");
                temp.setDosage(d);
               temp.setMedId(mDBHelper.getMedId(temp.getMedName()));
              temp.setMedContent(mDBHelper.getMedContent(temp.getMedName()));
                if(mQuantity.getText().toString().isEmpty()){
                    temp.setMedQuantity("null");
                }else {
                    temp.setMedQuantity((mQuantity.getText().toString()));
                }
                /*temp.setMedName("a");
                temp.setMedContent("d");
                temp.setMedId(1);
                temp.setMedQuantity(3);
                temp.setDosageE("Evening");
                temp.setDosageM("Morning");
                temp.setDosageA("Afternoon");
                */

                Intent intent = new Intent();
                intent.putExtra("object",temp);
                setResult(RESULT_OK, intent);
                finish();




            }
        });





    }
    private boolean CopyDatabase(Context context) {
        try {
            InputStream inputStream=context.getAssets().open(DatabaseHelper.DBNAME);
            String outFileName= DatabaseHelper.DBLOCATION+DatabaseHelper.DBNAME;
            OutputStream outputStream=new FileOutputStream(outFileName);
            byte[]buff=new byte[1024];
            int lenght=0;
            while((lenght = inputStream.read(buff))>0){
                outputStream.write(buff,0,lenght);
            }
            outputStream.flush();
            outputStream.close();
            Log.v("MainActivity","DB copied");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
