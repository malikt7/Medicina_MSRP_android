package medicina.msrp.cse.medicinamsrp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class PatientRegActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText EditUserEmail,EditUserPass;
    private Button BtnPatReg;

    private ProgressDialog progressDialog;

    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_reg);

        firebaseAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);

        EditUserEmail = (EditText) findViewById(R.id.EditUserEmail);
        EditUserPass = (EditText) findViewById(R.id.EditUserPass);
        BtnPatReg = (Button) findViewById(R.id.BtnPatReg);

        BtnPatReg.setOnClickListener(this);

    }
    private void registerUser(){
        String email = EditUserEmail.getText().toString().trim();
        String password = EditUserPass.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Please Enter Email", Toast.LENGTH_LONG).show();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please Enter Password", Toast.LENGTH_LONG).show();
            return;
        }

        progressDialog.setMessage("Registering User... Please Wait");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressDialog.dismiss();
                        if (task.isSuccessful()){
                            sendEmailVerification();
                            startActivity(new Intent(getApplicationContext(),RegSucActivity.class));
                        }
                        else{
                            Toast.makeText(PatientRegActivity.this, "Could Not Register.. Please Try Again", Toast.LENGTH_SHORT).show();
                        }
                    }
                });


    }

    private void sendEmailVerification() {

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user!=null){
            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if (task.isSuccessful()){
                        Toast.makeText(PatientRegActivity.this, "Check your email for verification", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    @Override
    public void onClick(View v) {
        if (v == BtnPatReg){
            registerUser();
        }
    }
}
