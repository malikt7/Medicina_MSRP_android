package medicina.msrp.cse.medicinamsrp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DocPanelActivity extends AppCompatActivity implements View.OnClickListener {
    Button BtnLogOut,BtnPatReg, BtnPre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_panel);

        BtnPatReg = (Button) findViewById(R.id.BtnPatReg);
        BtnPre = (Button) findViewById(R.id.BtnPre);
        BtnLogOut = (Button) findViewById(R.id.BtnLogOut);

        BtnPatReg.setOnClickListener(this);
        BtnPre.setOnClickListener(this);
        BtnLogOut.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        if (v == BtnPatReg) {
            startActivity(new Intent(this, PatientRegActivity.class));
        }

        if (v == BtnLogOut) {
            finish();
            startActivity(new Intent(this, DocLogActivity.class));
        }

        if (v == BtnPre) {
            startActivity(new Intent(this, PrescriptionLoginActivity.class));
        }

    }

}
