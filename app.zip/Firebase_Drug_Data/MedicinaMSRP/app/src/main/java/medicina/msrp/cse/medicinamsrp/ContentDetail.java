package medicina.msrp.cse.medicinamsrp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import medicina.msrp.cse.medicinamsrp.database.DatabaseHelper;
import medicina.msrp.cse.medicinamsrp.model.contentinfo;

public class ContentDetail extends AppCompatActivity {
    TextView txtname,txttemp;
    ListView showContent;
    Button btn;
    private List<contentinfo> mListContentInfo;
    private ListMedContentInfo madapter;
    String mname;
    String mcontent;
    int mId;
    DatabaseHelper mDBHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_detail);
        txtname=(TextView)findViewById(R.id.txtmedname);
        btn=(Button)findViewById(R.id.btncheck);
        txttemp=(TextView)findViewById(R.id.texttemp);
        showContent=(ListView) findViewById(R.id.listmedcontents);
       final Intent i=getIntent();
      mname=i.getExtras().getString("medname");
      mcontent=i.getExtras().getString("medcontent");
      mId=i.getExtras().getInt("medid");
        txtname.setText(mname);
        txttemp.setText(mname+" contains :");


        mDBHelper=new DatabaseHelper(this);

        File database=getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        if(false==database.exists()){
            mDBHelper.getReadableDatabase();
            if(CopyDatabase(this)){
                Toast.makeText(this,"copy database successfull",Toast.LENGTH_SHORT);
            }
            else{
                Toast.makeText(this,"copy database unsuccessfull",Toast.LENGTH_SHORT);
                return;
            }
        }
        else{
            Toast.makeText(this," database unsuccessfull",Toast.LENGTH_SHORT);
        }



         mListContentInfo=mDBHelper.getListContent(mId);
          madapter=new ListMedContentInfo(this,mListContentInfo);
         showContent.setAdapter(madapter);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ii=new Intent(getApplicationContext(),similarNames.class);
                String con=i.getExtras().getString("medcontent");
                ii.putExtra("medid1",con);
                startActivity(ii);
            }
        });




    }
    private boolean CopyDatabase(Context context) {
        try {
            InputStream inputStream=context.getAssets().open(DatabaseHelper.DBNAME);
            String outFileName= DatabaseHelper.DBLOCATION+DatabaseHelper.DBNAME;
            OutputStream outputStream=new FileOutputStream(outFileName);
            byte[]buff=new byte[1024];
            int lenght=0;
            while((lenght = inputStream.read(buff))>0){
                outputStream.write(buff,0,lenght);
            }
            outputStream.flush();
            outputStream.close();
            Log.v("MainActivity","DB copied");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
