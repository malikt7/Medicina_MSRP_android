package medicina.msrp.cse.medicinamsrp.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import medicina.msrp.cse.medicinamsrp.model.Product;
import medicina.msrp.cse.medicinamsrp.model.contentinfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Priyanka on 04-04-2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DBNAME="medicina12.db";
    public static final String DBLOCATION="/data/data/medicina.msrp.cse.medicinamsrp/databases/";
    private Context mContext;
    private SQLiteDatabase mDatabase;

    public DatabaseHelper(Context context){
        super(context,DBNAME,null,1);
        this.mContext=context;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void openDatabase(){
        String dbpath=mContext.getDatabasePath(DBNAME).getPath();
        if(mDatabase !=null && mDatabase.isOpen()){
            return;
        }
        mDatabase = SQLiteDatabase.openDatabase(dbpath,null,SQLiteDatabase.OPEN_READWRITE);
    }
    public void closeDatabase(){
        if(mDatabase !=null){
            mDatabase.close();
        }
    }
    public String getName(){
        String str;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT contentName from content WHERE contentNo=1",null);
        cursor.moveToFirst();
        str=cursor.getString(0);
        cursor.close();
        closeDatabase();
        return str;
    }
    public int getMedId(String a){
        int id;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("select drugNo from medicine where drugName='"+a+"'",null);
        cursor.moveToFirst();
        id=cursor.getInt(0);
        cursor.close();
        closeDatabase();
        return id;
    }
    public String getMedContent(String a){
        String str;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("select drugContent from medicine where drugName='"+a+"'",null);
        cursor.moveToFirst();
        str=cursor.getString(0);
        cursor.close();
        closeDatabase();
        return str;
    }
    public ArrayList<String> getListMedName(){
        //Product product=null;
        ArrayList<String> productList=new ArrayList<>();
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT drugName FROM medicine where drugType='brand'",null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            //product=new Product(cursor.getInt(0),cursor.getString(1),cursor.getString(2));
            productList.add(cursor.getString(0));
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return productList;


    }
    public contentinfo getcontent(int a){

        contentinfo mcontentInfo;
        openDatabase();
        Cursor cursor=mDatabase.rawQuery("SELECT * FROM content WHERE contentNo = "+a,null);
        cursor.moveToFirst();
        mcontentInfo=new contentinfo(cursor.getInt(0),cursor.getString(1),cursor.getString(2));
        return mcontentInfo;
    }
    public List<contentinfo> getListContent(int id){

        int temp;
        List<contentinfo> myList=new ArrayList<>();
        openDatabase();
        Cursor cursor = mDatabase.rawQuery("SELECT contentNoId FROM IndexOfContent WHERE drugNoId="+id+"",null);

       // Cursor cursor = mDatabase.rawQuery("SELECT contentNoId FROM IndexOfContent WHERE drugNoId= "+id+"",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            temp=cursor.getInt(0);
            myList.add(getcontent(temp));
            cursor.moveToNext();

        }
        cursor.close();
        closeDatabase();
        return myList;
    }
    public List<Product> getDrugName(String name){
        List<Product> medName=new ArrayList<>();
        Product p=null;
        openDatabase();

        Cursor cursor=mDatabase.rawQuery("SELECT drugName,drugType FROM medicine WHERE drugContent = '"+name+"'",null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            p=new Product(cursor.getString(0),cursor.getString(1));
            medName.add(p);
            cursor.moveToNext();
        }
        cursor.close();
        closeDatabase();
        return  medName;
    }

}
