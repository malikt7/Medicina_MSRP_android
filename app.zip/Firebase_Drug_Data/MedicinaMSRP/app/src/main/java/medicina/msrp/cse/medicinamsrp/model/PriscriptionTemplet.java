package medicina.msrp.cse.medicinamsrp.model;

import java.io.Serializable;

/**
 * Created by Priyanka on 09-04-2018.
 */

public class PriscriptionTemplet implements Serializable{
    private String medName,medContent,dosage;
    private int medId;
    private String medQuantity;

    public PriscriptionTemplet() {
    }


    public void setMedName(String medName) {
        this.medName = medName;
    }

    public void setMedContent(String medContent) {
        this.medContent = medContent;
    }



    public void setMedId(int medId) {
        this.medId = medId;
    }

    public void setMedQuantity(String medQuantity) {
        this.medQuantity = medQuantity;
    }

    public String getMedName() {
        return medName;
    }

    public String getMedContent() {
        return medContent;
    }


    public int getMedId() {
        return medId;
    }

    public String getMedQuantity() {
        return medQuantity;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }
}
