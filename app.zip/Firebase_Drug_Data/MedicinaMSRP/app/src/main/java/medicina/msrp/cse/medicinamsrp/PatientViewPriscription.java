package medicina.msrp.cse.medicinamsrp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import medicina.msrp.cse.medicinamsrp.database.DatabaseHelper;
import medicina.msrp.cse.medicinamsrp.model.PriscriptionTemplet;
import medicina.msrp.cse.medicinamsrp.model.contentinfo;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PatientViewPriscription extends AppCompatActivity {
    private List<contentinfo> mListContentInfo;
    private ListMedContentInfo madapter;
    private DatabaseReference mUserDatabase;
    private FirebaseUser mCurrentUser;
    private FirebaseDatabase firebaseDatabase;
   // DatabaseHelper mDBHelper;
    private ListView mypriscription;
    List<PriscriptionTemplet> pppp=new ArrayList<>();
    ShowPriscription adapter1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_view_priscription);

        mypriscription=(ListView)findViewById(R.id.list_view_content);


        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String current_uid = mCurrentUser.getUid();

        firebaseDatabase = FirebaseDatabase.getInstance();
        mUserDatabase = firebaseDatabase.getReference().child(current_uid).child("Prescription");




       // mDBHelper=new DatabaseHelper(this);
      //  mListContentInfo=mDBHelper.getListContent(5);
      //  madapter=new ListMedContentInfo(this,mListContentInfo);
      //  mycontent.setAdapter(madapter);
       /* FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message").child("priscription");*/
        mUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                for (DataSnapshot pris: dataSnapshot.getChildren()
                     ) {
                    PriscriptionTemplet p=pris.getValue(PriscriptionTemplet.class);
                    pppp.add(p);
                    
                }
                adapter1=new ShowPriscription(getApplicationContext(),pppp);
                mypriscription.setAdapter(adapter1);
                mypriscription.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String content=adapter1.getcontent(position);
                        int Id=adapter1.getid(position);
                       String name=adapter1.getname(position);
                        Intent myIntent=new Intent(getApplicationContext(),ContentDetail.class);
                         //myIntent.putExtra("MedName",itemname);
                       myIntent.putExtra("medname",name);
                      myIntent.putExtra("medcontent",content);
                       myIntent.putExtra("medid",Id);
                        startActivity(myIntent);




                    }
                });



            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value

            }
        });

    }
}
