package medicina.msrp.cse.medicinamsrp;

import android.app.Application;

/**
 * Created by Malik on 27/02/2018.
 */

public class docinfo extends Application {
    public String username="admin";
    public String password="1234";

    public docinfo() {
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

}
