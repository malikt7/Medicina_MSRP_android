package medicina.msrp.cse.medicinamsrp.model;

import java.io.Serializable;

/**
 * Created by Priyanka on 04-04-2018.
 */

public class test1 implements Serializable {
    String name;

    public test1(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public test1() {
    }

    public void setName(String name) {
        this.name = name;
    }
}
