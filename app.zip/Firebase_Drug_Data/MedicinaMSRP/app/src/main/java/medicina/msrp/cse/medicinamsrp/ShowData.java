package medicina.msrp.cse.medicinamsrp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


import medicina.msrp.cse.medicinamsrp.model.PriscriptionTemplet;
//import medicina.msrp.cse.medicinamsrp.model.test1;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class ShowData extends AppCompatActivity implements View.OnClickListener {
  //  private DatabaseHelper mDBHelper;
   // String strt;
   // TextView text;
    Button btn;
    private FirebaseAuth firebaseAuth;
    Button bth;
    Button blogout;
    private DatabaseReference databaseReference;
   // test1 testm;
   ListView show;
    //List<test1> t1=new ArrayList<test1>();
   // ListPriscription adapter;
    List<PriscriptionTemplet> t2=new ArrayList<PriscriptionTemplet>();
    ShowPriscription adapter1;
    PriscriptionTemplet pris;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);
        bth=(Button)findViewById(R.id.btnSubmit);

        firebaseAuth = FirebaseAuth.getInstance();

        databaseReference = FirebaseDatabase.getInstance().getReference();
       // mDBHelper=new DatabaseHelper(this);
       // text=(TextView)findViewById(R.id.textshow);
        btn=(Button)findViewById(R.id.btnstart);
        blogout=(Button)findViewById(R.id.btnsimilardrug);
        show=(ListView)findViewById(R.id.listview);
        //adapter=new ListPriscription(getApplicationContext(),t1);
       // show.setAdapter(adapter);

        adapter1=new ShowPriscription(getApplicationContext(),t2);
        show.setAdapter(adapter1);
        btn.setOnClickListener(this);
        bth.setOnClickListener(this);
        blogout.setOnClickListener(this);



        /*btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),AddPriscriptionToList.class);
                //startActivity(i);
                startActivityForResult(i, 1);

            }
        });*/

    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if(resultCode == RESULT_OK) {
                Bundle b = data.getExtras();
                if (b != null) {


                    pris=(PriscriptionTemplet)b.getSerializable("object");
                    t2.add(pris);
                    adapter1.notifyDataSetChanged();

                }
               // String strEditText = data.getStringExtra("editTextValue");

            }
        }
    }

    @Override
    public void onClick(View v) {
        if(v==btn){
            Intent i=new Intent(getApplicationContext(),AddPriscriptionToList.class);
            //startActivity(i);
            startActivityForResult(i, 1);
        }
        if(v==bth){
            FirebaseUser user = firebaseAuth.getCurrentUser();

            databaseReference.child(user.getUid()).child("Prescription").setValue(t2);

            Toast.makeText(this, "Prescription Saved...", Toast.LENGTH_LONG).show();

           // Intent i=new Intent(this,PatientViewPriscription.class);
            //startActivity(new Intent(this,PatientViewPriscription.class));
        }
        if(v==blogout){
            //startActivity(new Intent(this,similarNames.class));
            firebaseAuth.signOut();
            finish();
            startActivity(new Intent(this,DocPanelActivity.class ));
        }
    }
}
//testm=(test1)b.getSerializable("object");
//text.setText(testm.getName().toString());
//if(!testm.getName().toString().isEmpty()) {
//  t1.add(testm);
//adapter.notifyDataSetChanged();
//}
//else{
//  Toast.makeText(getApplicationContext(),"select medicine",Toast.LENGTH_SHORT).show();
//}
