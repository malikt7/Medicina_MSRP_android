package medicina.msrp.cse.medicinamsrp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import medicina.msrp.cse.medicinamsrp.database.DatabaseHelper;
import medicina.msrp.cse.medicinamsrp.model.Product;

import java.util.List;

public class similarNames extends AppCompatActivity {
    DatabaseHelper mDBHelper;
   ListView list;
   List<Product> similar;
   ListSimilarDrug adapter;
   String contentmed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_similar_names);
        Intent i=getIntent();
        contentmed=i.getExtras().getString("medid1");
        mDBHelper=new DatabaseHelper(this);
        list=(ListView)findViewById(R.id.listsimilar);
        similar=mDBHelper.getDrugName(contentmed);
        adapter=new ListSimilarDrug(this,similar);
        list.setAdapter(adapter);




    }
}
