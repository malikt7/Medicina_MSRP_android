package medicina.msrp.cse.medicinamsrp;

/**
 * Created by Malik on 28/02/2018.
 */

public class UserInfo {

    public String name;
    public String address;
    public String blood;


    public UserInfo(String name, String address, String blood) {
        this.name = name;
        this.address = address;
        this.blood = blood;
    }
}
